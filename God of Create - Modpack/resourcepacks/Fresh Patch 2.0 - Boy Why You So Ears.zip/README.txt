All credit to both JBCC, creator of "Boy Why You So Ears", and FreshLX, creator of "Fresh Animations"!

The pack includes a slight texture edit of JBCC's textures to fit with Fresh Animations' models, as well as an edit of the Fresh Animations wolf model adding larger ears.

Optifine /or/ EntityModelTextures+EntityModelFeatures is required for the model to function. If used alongside Fresh Animations, make sure this pack is either placed /above/ Fresh Animations /or/ replaces the base wolf model and spotted wolf textures.