Datapack for NeoForge 1.21.1
Registers selected TFMG fluids as Steam 'n' Rails liquid fuels.

Included fuels:
- propane
- butane
- naphtha
- kerosene
- gasoline
- diesel
- lpg

Balance used (fuel_ticks per 100 mB):
propane: 700
butane: 800
naphtha: 900
kerosene: 1050
gasoline: 1150
diesel: 1250
lpg: 1300

Notes:
- Assumes fluid ids are exactly tfmg:<name>, e.g. tfmg:diesel
- Put the zip into:
  .minecraft/saves/<world>/datapacks/
- Then run /reload in the world
